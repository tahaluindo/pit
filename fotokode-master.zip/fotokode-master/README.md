# fotokode
Jadikan kodemu menjadi gambar dengan berbagai tema yang keren

# Live Demo
<a href="http://fotokode.surge.sh/?bg=%23CFCACC&tema=okaidia&bahasa=javascript&code=%2F%2FPaste%20kodemu%20disini">Demo</a>

# Contoh
<p align="center">
  <img alt="example result" src="https://github.com/ricko-v/fotokode/blob/master/example.png"/>
</p>

# Dibuat dengan
<ol>
<li><a href="https://vuejs.org/">Vue.js</a></li>
<li><a href="https://router.vuejs.org/">Vue Router</a></li>
<li><a href="https://materializecss.com/">Materialize</a></li>
<li><a href="https://prismjs.com/">Prism</a></li>
<li><a href="https://github.com/tsayen/dom-to-image">Dom to Image</a></li>
<li><a href="https://jscolor.com/">jscolor</a></li>
</ol>
